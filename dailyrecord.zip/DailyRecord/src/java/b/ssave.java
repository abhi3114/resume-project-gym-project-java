/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author abhi
 */
@WebServlet(name = "ssave", urlPatterns = {"/ssave"})
public class ssave extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String email=request.getParameter("email");
        String uname=request.getParameter("username");
        String date=request.getParameter("date");        
        String months=request.getParameter("months");
        String day=request.getParameter("day");
        String timein=request.getParameter("timein");
        String timeout=request.getParameter("timeout");
        Connection c;
        
        try 
        {
             Class.forName("com.mysql.jdbc.Driver"); 
            c=DriverManager.getConnection("jdbc:mysql://localhost/member","root","");

            Statement statement = c.createStatement();
             

            ResultSet resultset = 
                statement.executeQuery("Select * from srecord where date='"+date+"' && email='"+email+"' ") ; 
                
            if(resultset.next())
            {
                 request.getRequestDispatcher("Staff/dailyentry.jsp").include(request, response);
                 out.println("<script type=\"text/javascript\">");
                out.println("alert('Sorry,Data cannot be inserted again');");
                out.println("</script>");
               
               
            } 
            else
            {
            try
                {
                   // String s="";
                    request.getRequestDispatcher("Staff/dailyentry.jsp").include(request, response);
                     Class.forName("com.mysql.jdbc.Driver");
             c=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/member","root","");           
            PreparedStatement ps=c.prepareStatement("insert into srecord value(?,?,?,?,?,?,?,?)",PreparedStatement.RETURN_GENERATED_KEYS);           
            ps.setString(1,null);
            ps.setString(2,email);
            ps.setString(3,uname);            
            ps.setString(4,months);
            ps.setString(5,day);
            ps.setString(6,date);
            ps.setString(7,timein);
            ps.setString(8,timeout);
            ps.executeUpdate();
            ps.close();
            c.close();            
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Data inserted sucessfully');");
            out.println("</script>");
               
                
           
                }
                catch(Exception e)
                {
                    request.getRequestDispatcher("Staff/dailyentry.jsp").include(request, response);
                    out.println(e);
                    
                }
            
            }
        }
        catch(Exception e1)
        {    
            request.getRequestDispatcher("Staff/dailyentry.jsp").include(request, response);
             out.println(e1);
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
