/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package astaff;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author abhi
 */
@WebServlet(name = "salsave", urlPatterns = {"/salsave"})
public class salsave extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String email=request.getParameter("semail");
        String firstname=request.getParameter("sfirstname");
        String jobshift=request.getParameter("sjobshift");
        String doj=request.getParameter("sdoj");
        String lm=request.getParameter("lm");
        String salary=request.getParameter("salary");
        String nabsent=request.getParameter("nabsent");
        String sdeducted=request.getParameter("sdeducted");
        String  sreceive=request.getParameter("sreceive");
       Connection c;
       PreparedStatement ps;
        try 
        {
            Class.forName("com.mysql.jdbc.Driver"); 
            c=DriverManager.getConnection("jdbc:mysql://localhost/member","root","");

            Statement statement = c.createStatement();
             

            ResultSet resultset = 
                statement.executeQuery("Select * from staffsalary where email='"+email+"' && firstname='"+firstname+"' && lastmonth='"+lm+"' ") ; 
                
            if(resultset.next())
            {
                 out.println("<script type=\"text/javascript\">");
                 out.println("alert('Sorry,Data cannot be inserted again.');");
                out.println("</script>");
           
                 request.getRequestDispatcher("sdetail/staffsalary.jsp").include(request, response);               
               
            } 
            else
            {
               
                   Class.forName("com.mysql.jdbc.Driver");
                   c=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/member","root","");           
                   ps=c.prepareStatement("insert into staffsalary value(?,?,?,?,?,?,?,?,?,?)",PreparedStatement.RETURN_GENERATED_KEYS);                       
                   ps.setString(1,null);
                   ps.setString(2,email);
                   ps.setString(3,firstname);
                   ps.setString(4,jobshift);
                   ps.setString(5,doj);
                   ps.setString(6,lm);
                   ps.setString(7,salary);
                   ps.setString(8,nabsent);
                   ps.setString(9,sdeducted);
                   ps.setString(10,sreceive);                   
                   ps.executeUpdate();
                   ps.close();
                   c.close();
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Data save Successfully.');");
                    out.println("</script>");
                    request.getRequestDispatcher("sdetail/staffsalary.jsp").include(request, response);
           
                    try
                {
                   
             Class.forName("com.mysql.jdbc.Driver");
             c=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/member","root","");           
            ps=c.prepareStatement("Update staff set jobshift=?,doj=? where email=? && firstname=? ");           
            ps.setString(1,jobshift);
            ps.setString(2,doj);
            ps.setString(3,email);
            ps.setString(4,firstname);
            ps.executeUpdate();
            ps.close();
            c.close();                                       
                }
                catch(Exception e)
                {
                    
                    out.println(e);
                    
                }
        

                
                
            }
           
        }
        catch(Exception e)
        {
            //out.println(e);
             out.println("<script type=\"text/javascript\">");
             out.println("alert('Please First Enter D.O.J of staff in new staff Entry tab.');");
             out.println("</script>");
                   
            request.getRequestDispatcher("sdetail/staffsalary.jsp").include(request, response);
        }
            
            
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
