/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package astaff;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author abhi
 */
@WebServlet(name = "staffedit", urlPatterns = {"/staffedit"})
public class staffedit extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
         String email=request.getParameter("email");
        String fname=request.getParameter("firstname");   
        String mname=request.getParameter("middlename"); 
        String lname=request.getParameter("lastname");
        String address=request.getParameter("address");
        String country=request.getParameter("country");
        String state=request.getParameter("state");
        String district=request.getParameter("district");
        int pincode=Integer.parseInt(request.getParameter("pincode"));               
        String dob=request.getParameter("dob");
         String gender=request.getParameter("gender");
         String password=request.getParameter("password");
         String cpassword=request.getParameter("cpassword");        
        String mobile=request.getParameter("mobile");
        String phone=request.getParameter("phone");
        String cw=request.getParameter("cweight");       
        String height=request.getParameter("height");
        int age=Integer.parseInt(request.getParameter("age"));
        String qualification=request.getParameter("qualification");
        String exp=request.getParameter("experience");
        String reason=request.getParameter("reason");
        String question=request.getParameter("question");
        String answer=request.getParameter("answer");
        Connection c;
       
        try
        {
                      
            Class.forName("com.mysql.jdbc.Driver");
            c=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/member","root","");           
            PreparedStatement ps=c.prepareStatement("Update staff set firstname=?,middlename=?,lastname=?,address=?,country=?,state=?,district=? ,pincode=? ,dob=?,gender=?,password=?,cpassword=? ,mobile=? ,phone=? ,currentweight=? ,height=?,age=? ,qualification=?,experience=?,joiningreason=?,question=?,security=? where email=?");           
            ps.setString(1,fname);
            ps.setString(2,mname);
            ps.setString(3,lname);
            ps.setString(4,address);
            ps.setString(5,country);
            ps.setString(6,state);
            ps.setString(7,district);
            ps.setInt(8,pincode);
            ps.setDate(9,new java.sql.Date(( new SimpleDateFormat("yyyy-MM-dd").parse(dob)).getTime()));
            ps.setString(10,gender);
            ps.setString(11,password);
            ps.setString(12,cpassword);
             ps.setString(13,mobile);
            ps.setString(14,phone);                       
            ps.setString(15,cw);
            ps.setString(16,height);
            ps.setInt(17,age);
            ps.setString(18,qualification);
            ps.setString(19,exp);
            ps.setString(20,reason);
            ps.setString(21,question);
            ps.setString(22,answer);
            ps.setString(23,email);
            ps.executeUpdate();
            ps.close();
            c.close();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Information Updated Successfully.');");
            out.println("</script>");
            request.getRequestDispatcher("sdetail/staffedit.jsp").include(request, response);
        
               
        }
        catch(Exception e)
        {
       out.println(e);
      
       request.getRequestDispatcher("sdetail/staffedit.jsp").include(request, response);
        }
        
        
         try 
        {
             Class.forName("com.mysql.jdbc.Driver"); 
            c=DriverManager.getConnection("jdbc:mysql://localhost/member","root","");

            Statement statement = c.createStatement();
             

            ResultSet resultset = 
                statement.executeQuery("Select * from staffsalary where  email='"+email+"'&& firstname='"+fname+"' ") ; 
                
            if(resultset.next())
            {
                
            } 
            else
            {
        
                try 
                {
           
                Class.forName("com.mysql.jdbc.Driver");
                 c=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/member","root","");           
                PreparedStatement ps=c.prepareStatement("Update staffsalary set firstname=? where email=? ");                       
                ps.setString(1,fname);
                ps.setString(2,email);            
                ps.executeUpdate();
                ps.close();
                c.close();
            
           
           
                 }
                catch(Exception e)
                  {
                     out.println(e);
            
                   }
             
            }
        }
          catch(Exception e1)
        {            
             out.println(e1);
            
        }
        
        
        try 
        {
             Class.forName("com.mysql.jdbc.Driver"); 
            c=DriverManager.getConnection("jdbc:mysql://localhost/member","root","");

            Statement statement = c.createStatement();
             

            ResultSet resultset = 
                statement.executeQuery("Select * from srecord where  email='"+email+"'&& firstname='"+fname+"' ") ; 
                
            if(resultset.next())
            {
                
            } 
            else
            {
               try 
            {
           
            Class.forName("com.mysql.jdbc.Driver");
           c=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/member","root","");           
            PreparedStatement ps=c.prepareStatement("Update srecord set firstname=? where email=? ");                       
            ps.setString(1,fname);
            ps.setString(2,email);            
            ps.executeUpdate();
            ps.close();
            c.close();
            
           
           
         }
         catch(Exception e)
            {
            out.println(e);
            
             }
        
            }
        }
          catch(Exception e1)
        {            
             out.println(e1);
            
        }
        
        
        
        
        
          
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    
}