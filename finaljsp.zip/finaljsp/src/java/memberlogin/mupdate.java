/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package memberlogin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author abhi
 */
@WebServlet(name = "mupdate", urlPatterns = {"/mupdate"})
public class mupdate extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String email=request.getParameter("semail");
        String fname=request.getParameter("fname");   
        String mname=request.getParameter("mname"); 
        String lname=request.getParameter("lname");
        String address=request.getParameter("address");
        int pincode=Integer.parseInt(request.getParameter("pincode"));               
        String dob=request.getParameter("dob");
         String gender=request.getParameter("gender");
        int age=Integer.parseInt(request.getParameter("age"));
        String mobile=request.getParameter("mobile");
        String phone=request.getParameter("phone");
        String cw=request.getParameter("cweight");
        String gw=request.getParameter("gweight");
        String height=request.getParameter("height");
        String question=request.getParameter("question");
        String answer=request.getParameter("answer");
        
         Connection c;
        try
        {
                      
            Class.forName("com.mysql.jdbc.Driver");
           c=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/member","root","");           
            PreparedStatement ps=c.prepareStatement("Update member set firstname=?,middlename=?,lastname=?,address=? ,pincode=? ,dob=?,gender=? ,age=?,mobile=? ,phone=? ,currentweight=? ,gweight=? ,height=?,question=?,security=? where email=?");           
            ps.setString(1,fname);
            ps.setString(2,mname);
            ps.setString(3,lname);
            ps.setString(4,address);
            ps.setInt(5,pincode);
            ps.setDate(6,new java.sql.Date(( new SimpleDateFormat("yyyy-MM-dd").parse(dob)).getTime()));
            ps.setString(7,gender);
            ps.setInt(8,age);
            ps.setString(9,mobile);
            ps.setString(10,phone);
            ps.setString(11,cw);
            ps.setString(12,gw);
            ps.setString(13,height);
            ps.setString(14,question);
            ps.setString(15,answer);
            ps.setString(16,email);
            ps.executeUpdate();
            ps.close();
            c.close();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Information Updated Successfully.');");
            out.println("</script>");
            request.getRequestDispatcher("navabar/mlogin/mprofile.jsp").include(request, response);
        
               
        }
        catch(Exception e)
        {
       out.println(e);
      
       request.getRequestDispatcher("navabar/mlogin/mprofile.jsp").include(request, response);
        }
          try 
            {
           
            Class.forName("com.mysql.jdbc.Driver");
           c=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/member","root","");           
            PreparedStatement ps=c.prepareStatement("Update mpayment set firstname=? where email=? ");                       
            ps.setString(1,fname);
            ps.setString(2,email);            
            ps.executeUpdate();
            ps.close();
            c.close();
            
           
           
         }
         catch(Exception e)
            {
            out.println(e);
            
             }
        
        
         try 
        {
             Class.forName("com.mysql.jdbc.Driver"); 
            c=DriverManager.getConnection("jdbc:mysql://localhost/member","root","");

            Statement statement = c.createStatement();
             

            ResultSet resultset = 
                statement.executeQuery("Select * from mrecord where  email='"+email+"'&& firstname='"+fname+"' ") ; 
                
            if(resultset.next())
            {
                
            } 
            else
            {
               try 
            {
           
            Class.forName("com.mysql.jdbc.Driver");
           c=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/member","root","");           
            PreparedStatement ps=c.prepareStatement("Update mrecord set firstname=? where email=? ");                       
            ps.setString(1,fname);
            ps.setString(2,email);            
            ps.executeUpdate();
            ps.close();
            c.close();
            
           
           
         }
         catch(Exception e)
            {
            out.println(e);
            
             }
        
            }
        }
          catch(Exception e1)
        {            
             out.println(e1);
            
        }
        
       
        
        
        
        
        
        
        
        
        
        
          
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    

}