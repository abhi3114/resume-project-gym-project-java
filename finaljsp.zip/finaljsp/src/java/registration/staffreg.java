/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author abhi
 */
@WebServlet(name = "staffreg", urlPatterns = {"/staffreg"})
public class staffreg extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
       String fname=request.getParameter("firstname");
       String mname=request.getParameter("middlename");
       String lname=request.getParameter("lastname");
       String add=request.getParameter("address");
       String country=request.getParameter("country");
       String state=request.getParameter("state");
       String district=request.getParameter("district");     
       int pincode=Integer.parseInt(request.getParameter("pincode"));
       String dob=request.getParameter("dob");
       String gender=request.getParameter("gender");
       String email=request.getParameter("email");
       String pass=request.getParameter("password");
       String cpass=request.getParameter("cpassword");
       String mobile=request.getParameter("mobile");
       String phone=request.getParameter("phone");
       String cw=request.getParameter("cweight");
       String height=request.getParameter("height");
       int age=Integer.parseInt(request.getParameter("age"));
       String dor=request.getParameter("dor");
       String qualification=request.getParameter("qualification");
       String experience=request.getParameter("experience");
       String js=request.getParameter("jobshift");      
       String reason=request.getParameter("reason");
       String question=request.getParameter("question");
       String security=request.getParameter("answer");
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection c=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/member","root","");
            PreparedStatement ps=c.prepareStatement("insert into staff value(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",PreparedStatement.RETURN_GENERATED_KEYS);           
            ps.setString(1,null);
            ps.setString(2,fname);
            ps.setString(3,mname);
            ps.setString(4,lname);
            ps.setString(5,add);
            ps.setString(6,country);
            ps.setString(7,state);
            ps.setString(8,district);
            ps.setInt(9,pincode);
            ps.setString(10,dob);
            ps.setString(11,gender);
            ps.setString(12,email);
            ps.setString(13,pass);
            ps.setString(14,cpass);
            ps.setString(15,mobile);
            ps.setString(16,phone);
            ps.setString(17,cw);
            ps.setString(18,height);
            ps.setInt(19,age);
            ps.setString(20,dor);
            ps.setString(21,qualification);
            ps.setString(22,experience);
            ps.setString(23,js);            
            ps.setString(24,reason);
            ps.setString(25,question);
            ps.setString(26,security);
            ps.setString(27,null);
            ps.executeUpdate();
            ps.close();
            c.close();
            
       out.println("<script type=\"text/javascript\">");
       out.println("alert('Data have been saved successfully');");
       out.println("</script>");
       request.getRequestDispatcher("homepage/homepage.jsp").include(request, response); 
                                    
            
        }
        catch(Exception e)
        {
            //out.println(e);
       out.println("<script type=\"text/javascript\">");
       out.println("alert('Please enter new email-id.The email you are trying to enter is already in used.');");
       out.println("</script>");
       request.getRequestDispatcher("registrationform/registrationstaff.jsp").include(request, response);
       
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
