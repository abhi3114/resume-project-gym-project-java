-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2017 at 10:03 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webpage`
--

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `userid` int(11) NOT NULL,
  `question` varchar(150) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`userid`, `question`, `firstname`, `contact`, `email`) VALUES
(1, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'abhishek', '9869011741', 'chavanabhi001@gmail.com'),
(4, 'dddddddddddddddddddddddddddddddddd', 'pakya', '9869011741', 'pratikjoil999@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `offer`
--

CREATE TABLE `offer` (
  `id` int(11) NOT NULL,
  `hideshow` varchar(10) NOT NULL,
  `offername` varchar(100) NOT NULL,
  `col1` varchar(100) NOT NULL,
  `col2` varchar(100) NOT NULL,
  `col3` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offer`
--

INSERT INTO `offer` (`id`, `hideshow`, `offername`, `col1`, `col2`, `col3`) VALUES
(1, 'show', 'SUMMER OFFER VALID TILL 31-5-2017', '1 MONTH-500 RS<BR>3 MONTH-900 RS<BR>6 MONTH-1,700 RS<BR>12 MONTH-2,600 RS<BR>', '15 MONTHS GYM MEMBER-SHIP OFFER OF ONLY 2,600 RS<br> VALID TILL 15-5-2017', 'COUPLE MEMBER-SHIP OFFER OF ONLY 4,000 RS<br> VALID TILL 10-5-2017');

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `userid` int(11) NOT NULL,
  `yearsmonths` varchar(50) NOT NULL,
  `gymandcardio` varchar(50) NOT NULL,
  `onlygym` varchar(50) NOT NULL,
  `onlycardio` varchar(50) NOT NULL,
  `discount` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`userid`, `yearsmonths`, `gymandcardio`, `onlygym`, `onlycardio`, `discount`) VALUES
(1, '2 years', '10,000 Rs', '5,000Rs', '5,000 Rs', '20%'),
(2, '1 year', '5,000 Rs', '2,600 Rs', '2,600 Rs', '15%'),
(3, '6 months', '3,400 Rs', '1,700 Rs', '1,700 Rs', '10%'),
(4, '3 months', '1,900 Rs', '950 Rs', '950 Rs', '5%'),
(5, '1 month', '1,000 Rs', '500 Rs', '500 Rs', 'no discount');

-- --------------------------------------------------------

--
-- Table structure for table `staffpanel`
--

CREATE TABLE `staffpanel` (
  `id` int(11) NOT NULL,
  `hideshow` varchar(10) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `col1` varchar(200) DEFAULT NULL,
  `col2` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffpanel`
--

INSERT INTO `staffpanel` (`id`, `hideshow`, `title`, `col1`, `col2`) VALUES
(1, 'show', 'STAFF REQUIREMENT', 'EDUCATION: 12TH pass/Graduate.<br><br>EXPERIENCE: min 2 years.<br><br>SPECIAL COURCE:Certified Trainer.<br><br>Fresher can also apply', 'SALARY: min 15,000 Rs<br><br> WORKING HOURS: 8 hours<br><br> For Fresher <br>SALARY:10,000Rs<br><br>WORKING HOURS:12 hrs'),
(2, 'show', 'IMPORTANT NOTICE FOR GYM MEMBER.!!!!!!!<BR>GYM WILL BE CLOSED ON TUESDAY i.e 02-3-2017.', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `offer`
--
ALTER TABLE `offer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `staffpanel`
--
ALTER TABLE `staffpanel`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
