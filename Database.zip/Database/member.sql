-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2017 at 10:03 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `member`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `userid` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(10) NOT NULL,
  `cpassword` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `dob` date DEFAULT NULL,
  `question` varchar(100) NOT NULL,
  `security` varchar(20) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `gymemail` varchar(30) DEFAULT NULL,
  `contact1` varchar(10) DEFAULT NULL,
  `contact2` varchar(10) DEFAULT NULL,
  `map` varchar(900) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`userid`, `email`, `password`, `cpassword`, `name`, `dob`, `question`, `security`, `address`, `gymemail`, `contact1`, `contact2`, `map`) VALUES
(1, 'admin123@gmail.com', 'admin123', 'admin123', 'administrator', '1996-03-30', 'what is your dog name??', 'siya', 'Eden Garden Cooperative Housing Society, Citi Park Rd, Sector - 8, Khanda Colony, Panvel, Navi Mumbai, Maharashtra 410206;', 'muscleslinegym2005@gmail.com', '9768727025', '9870805830', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3772.2984279826833!2d73.10885731437575!3d19.006567059091527!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7e8362b69d211%3A0x216227741de391b4!2sMuscle&#39;s+Line+Gym!5e0!3m2!1sen!2sin!4v1489929317781" width="400" height="300" frameborder="0" style="border:0" class="embed-responsive-item" allowfullscreen ></iframe>           \r\n'),
(2, 'chavanabhi001@gmail.com', 'abhi3718', 'abhi3718', 'abhishek', '1996-03-30', 'What is your pet name???', 'mahi', NULL, NULL, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `user-id` int(11) NOT NULL,
  `firstname` varchar(15) NOT NULL,
  `middlename` varchar(15) NOT NULL,
  `lastname` varchar(15) DEFAULT NULL,
  `address` varchar(150) NOT NULL,
  `country` varchar(15) NOT NULL,
  `state` varchar(15) NOT NULL,
  `district` varchar(15) NOT NULL,
  `pincode` int(6) NOT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL,
  `cpassword` varchar(8) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `package` varchar(15) NOT NULL,
  `years` varchar(10) NOT NULL,
  `doj` date DEFAULT NULL,
  `currentweight` varchar(6) NOT NULL,
  `gweight` varchar(6) NOT NULL,
  `height` varchar(5) NOT NULL,
  `age` int(2) NOT NULL,
  `question` varchar(100) NOT NULL,
  `security` varchar(15) NOT NULL,
  `familymember` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`user-id`, `firstname`, `middlename`, `lastname`, `address`, `country`, `state`, `district`, `pincode`, `dob`, `gender`, `email`, `password`, `cpassword`, `mobile`, `phone`, `package`, `years`, `doj`, `currentweight`, `gweight`, `height`, `age`, `question`, `security`, `familymember`) VALUES
(1, 'abhishek', 'ravindra', 'chavan', 'khanchanganga chs plot no.c/4,sector-07,khanda colony,new panvel(west).', 'india', 'maharashtra', 'raigad', 410206, '1996-03-03', 'Male', 'chavanabhi001@gmail.com', 'abhi3718', 'abhi3718', '9869011741', '9920839370', 'Only Cardio', '3 months', '2017-01-26', '060.00', '068.00', '05.69', 18, 'What is your dog name???', 'siya', 'no'),
(5, 'swapnil', 'bhairu', 'kamble', 'b-203 sadguru co-op society sector-7 plot no-13 khanda colony new panvel', 'india', 'maharashtra', 'raigad', 410206, '1996-02-28', 'male', 'kamble.swapnil96@gmail.com', 'swapnilk', 'swapnilk', '9773714164', '9773714164', 'gym + cardio', '2 years', '2017-02-21', '056.00', '060.00', '05.06', 20, 'What is your favourite teacher name???', 'mahi', 'no'),
(6, 'akash', 'shyamal', 'biswas', 'G-66,sector-3,Airoli,Navi Mumbai 400708', 'India', 'maharashtra', 'Thane', 400708, '1996-02-01', 'male', 'akashbiswas144@gmail.com', 'A12345c', 'A12345c', '9933399333', '9933399333', 'only gym', '2 years', '2017-02-22', '073.00', '200.00', '05.05', 21, 'What is your favourite food???', 'rasgulla', 'no'),
(7, 'jerin', 'johnson', '', 'man nivas sce-14 nerul ', 'india', 'maharashtra', 'thane', 400706, '1996-07-22', 'male', 'johnsonjerin000@gmail.com', 'jerin123', 'jerin123', '9855521701', '9855251201', 'only gym', '1 month', '2017-02-22', '075.00', '080.00', '07.06', 20, 'What is your favourite food???', 'beef', 'no'),
(8, 'Kedar', 'laxman', 'bhoir', 'at bhendkhal post jnpt talkula uran', 'india', 'maharashtra', 'raigad', 400707, '1993-05-25', 'male', 'kedarbhoir25@gmail.com', 'kedar123', 'kedar123', '7208365973', '9869011741', 'gym + cardio', '6 months', '2017-02-22', '110.00', '080.00', '05.05', 23, 'What is your favourite teacher name???', 'varsha', 'no'),
(9, 'suraj', 'nana', 'karde', 'kharghar sector15 gharkhul', 'india', 'maharashtra', 'raigad', 410210, '1996-09-19', 'male', 'surajkarde014@gmail.com', 'surajnan', 'surajnan', '9819716912', '9820889801', 'gym + cardio', '1 year', '2017-02-22', '065.00', '080.00', '05.09', 21, 'What is your dog name???', 'nana', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `mpayment`
--

CREATE TABLE `mpayment` (
  `userid` int(11) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `firstname` varchar(15) DEFAULT NULL,
  `package` varchar(20) DEFAULT NULL,
  `years` varchar(10) DEFAULT NULL,
  `offer` varchar(10) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `dop` date DEFAULT NULL,
  `doe` date DEFAULT NULL,
  `total` varchar(10) DEFAULT NULL,
  `payment` varchar(20) DEFAULT NULL,
  `balance` varchar(20) DEFAULT NULL,
  `receiveby` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mpayment`
--

INSERT INTO `mpayment` (`userid`, `email`, `firstname`, `package`, `years`, `offer`, `doj`, `dop`, `doe`, `total`, `payment`, `balance`, `receiveby`) VALUES
(1, 'chavanabhi001@gmail.com', 'abhishek', 'Only Cardio', '3 months', 'no', '2017-01-06', '2017-02-05', '2017-07-01', '3,000 Rs', '3,000 Rs', '0 Rs', 'aaa'),
(5, 'kamble.swapnil96@gmail.com', 'swapnil', 'gym + cardio', '2 years', 'no', '2017-02-21', '2017-02-21', '2019-02-21', '20,000 Rs', '20,000 Rs', '0 Rs', 'admin'),
(6, 'akashbiswas144@gmail.com', 'akash', 'only gym', '2 years', 'no', '2017-02-22', '2017-03-06', '2019-03-06', '20,000 Rs', '20,000 Rs', '0 Rs', 'pratik'),
(7, 'johnsonjerin000@gmail.com', 'jerin', 'only gym', '1 month', 'yes', '2017-02-22', '2017-05-01', '2017-09-02', '3,000 Rs', '3,000 Rs', '1,000 Rs', 'owner'),
(8, 'kedarbhoir25@gmail.com', 'Kedar', 'gym + cardio', '6 months', NULL, '2017-02-22', NULL, NULL, NULL, NULL, NULL, ''),
(9, 'surajkarde014@gmail.com', 'suraj', 'gym + cardio', '1 year', NULL, '2017-02-22', NULL, NULL, NULL, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `mrecord`
--

CREATE TABLE `mrecord` (
  `userid` int(11) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `firstname` varchar(15) DEFAULT NULL,
  `workout` varchar(20) DEFAULT NULL,
  `month` varchar(20) DEFAULT NULL,
  `day` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `timein` varchar(10) DEFAULT NULL,
  `timeout` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mrecord`
--

INSERT INTO `mrecord` (`userid`, `email`, `firstname`, `workout`, `month`, `day`, `date`, `timein`, `timeout`) VALUES
(1, 'chavanabhi001@gmail.com', 'abhishek', 'chest', 'February', 'Saturday', '2017-02-04', '10:20 am', '11:30 am'),
(2, 'chavanabhi001@gmail.com', 'abhishek', 'chest', 'February', 'Saturday', '2017-02-11', '10:20 am', '01:30 am'),
(7, 'kamble.swapnil96@gmail.com', 'swapnil', 'chest and tricep', 'February', 'Tuesday', '2017-02-21', '09:33 pm', '10:30 pm'),
(6, 'chavanabhi001@gmail.com', 'abhishek', 'legs', 'February', 'Sunday', '2017-02-19', '10:20 am', '11:30 am'),
(8, 'chavanabhi001@gmail.com', 'abhishek', 'chest', 'February', 'Wednesday', '2017-02-22', '10:20 am', '11:30 am'),
(9, 'chavanabhi001@gmail.com', 'abhishek', 'back and biceps', 'March', 'Friday', '2017-03-03', '7:20 am', '8:30 am'),
(10, 'chavanabhi001@gmail.com', 'abhishek', 'chest and legs', 'March', 'Sunday', '2017-03-05', '10:20 am', '11:20 am'),
(11, 'chavanabhi001@gmail.com', 'abhishek', 'chest and tricep', 'March', 'Friday', '2017-03-10', '5:15 pm', '6:15 pm'),
(12, 'chavanabhi001@gmail.com', 'abhishek', 'chest', 'March', 'Tuesday', '2017-03-28', '10:20 am', '11:30 am');

-- --------------------------------------------------------

--
-- Table structure for table `srecord`
--

CREATE TABLE `srecord` (
  `userid` int(11) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `firstname` varchar(15) DEFAULT NULL,
  `month` varchar(20) DEFAULT NULL,
  `day` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `timein` varchar(10) DEFAULT NULL,
  `timeout` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `srecord`
--

INSERT INTO `srecord` (`userid`, `email`, `firstname`, `month`, `day`, `date`, `timein`, `timeout`) VALUES
(1, 'pratikjoil999@gmail.com', 'pratik', 'February', 'Saturday', '2017-02-04', '01:20 am', '01:30 am'),
(2, 'pratikjoil999@gmail.com', 'pratik', 'February', 'Monday', '2017-02-06', '10:20 am', '11:30 am'),
(3, 'pratikjoil999@gmail.com', 'pratik', 'February', 'Saturday', '2017-02-11', '05:20 am', '11:30 am'),
(11, 'kamble.swapnil96@gmail.com', 'swapnil', 'February', 'Tuesday', '2017-02-21', '10:20 am', '05:30 pm'),
(10, 'pratikjoil999@gmail.com', 'pratik', 'February', 'Sunday', '2017-02-19', '08:17 pm', '11:30 pm'),
(12, 'pratikjoil999@gmail.com', 'pratik', 'March', 'Monday', '2017-03-06', '10:20 am', '05:30 pm');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `userid` int(11) NOT NULL,
  `firstname` varchar(15) NOT NULL,
  `middlename` varchar(15) NOT NULL,
  `lastname` varchar(15) DEFAULT NULL,
  `address` varchar(150) NOT NULL,
  `country` varchar(15) NOT NULL,
  `state` varchar(15) NOT NULL,
  `district` varchar(15) NOT NULL,
  `pincode` int(6) NOT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL,
  `cpassword` varchar(8) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `currentweight` varchar(6) NOT NULL,
  `height` varchar(6) NOT NULL,
  `age` int(2) NOT NULL,
  `dor` date DEFAULT NULL,
  `qualification` varchar(20) NOT NULL,
  `experience` varchar(10) NOT NULL,
  `jobshift` varchar(15) NOT NULL,
  `joiningreason` varchar(150) NOT NULL,
  `question` varchar(100) NOT NULL,
  `security` varchar(15) NOT NULL,
  `doj` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`userid`, `firstname`, `middlename`, `lastname`, `address`, `country`, `state`, `district`, `pincode`, `dob`, `gender`, `email`, `password`, `cpassword`, `mobile`, `phone`, `currentweight`, `height`, `age`, `dor`, `qualification`, `experience`, `jobshift`, `joiningreason`, `question`, `security`, `doj`) VALUES
(1, 'pratik', 'anil', 'joil', 'pl-5 new panvel,sector-07,(east)', 'india', 'maharshtra', 'raigad', 410206, '1996-06-12', 'Male', 'pratikjoil999@gmail.com', 'pratik58', 'pratik58', '8108074627', '9321721557', '170.70', '75.20', 21, '2017-01-31', 'bscit', '3 years', 'morning', 'To learn new things.As well as to enchance my knowledge', 'To learn new things.As well as to enchance my knowledge', 'mahi', '2017-02-10'),
(8, 'swapnil', 'bhairu', 'kamble', 'b-203 sadguru co-op society sector-7 plot no-13 khanda colony', 'india', 'maharashtra', 'raigad', 410206, '1996-02-28', 'male', 'kamble.swapnil96@gmail.com', 'swapnilk', 'swapnilk', '9773714164', '9773714164', '056.00', '05.06', 21, '2017-02-21', 'Bsc.it', '2 years', 'morning', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'What is your favourite teacher name???', 'mahi', '2017-02-21'),
(9, 'akshay', 'sanjay', 'chavan', 'prime rose arcade plot no 119 room no 104 sec 13 kharghar ', 'india', 'maharashtra', 'raigad', 410210, '1996-06-18', 'male', '18akshaychavan@gmail.com', 'akshay97', 'akshay97', '9167636704', '9167896709', '071.00', '05.07', 21, '2017-02-22', 'bsc.it', 'Fresher', 'afternoon', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'What is your dog name???', 'gaurav', NULL),
(10, 'gaurav', 'sandeep', 'deshmukh', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'india', 'maharashtra', 'raigad', 410206, '1995-06-12', 'male', 'gaurav3deshmukh@gmail.com', 'deshmukh', 'deshmukh', '9820982205', '9867987867', '081.00', '05.09', 26, '2017-02-22', 'bsc.it', '2 years', 'morning', 'dddddddddddddddddddddddddddddddddddddddddddddddddd', 'What is your favourite food???', 'panipuri', NULL),
(15, 'abhishek', 'ravindra', 'aaaaaaaa', 'aaaaaaaaaaaa\r\n', 'aaaaaaaaaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaaa', 111111, '1995-06-12', 'male', 'ramesh99@gmail.com', 'aaaaaaaa', 'aaaaaaaa', '1111111111', '1111111111', '090.75', '07.20', 21, '2017-05-01', 'aaaaaaaaaaaa', 'aaaaa', 'morning', 'aaaaaaaaaaa \r\n\r\naaaaaaaaaaaaaaaaaaaaaaaaaa\r\n', 'What is your favourite teacher name???', 'aaaaaaaa', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `staffsalary`
--

CREATE TABLE `staffsalary` (
  `userid` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `firstname` varchar(15) NOT NULL,
  `jobshift` varchar(15) NOT NULL,
  `doj` date DEFAULT NULL,
  `lastmonth` date DEFAULT NULL,
  `salary` varchar(10) DEFAULT NULL,
  `dayabsent` varchar(10) DEFAULT NULL,
  `sdeducted` varchar(10) DEFAULT NULL,
  `sreceive` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffsalary`
--

INSERT INTO `staffsalary` (`userid`, `email`, `firstname`, `jobshift`, `doj`, `lastmonth`, `salary`, `dayabsent`, `sdeducted`, `sreceive`) VALUES
(1, 'pratikjoil999@gmail.com', 'pratik', 'morning', '2017-02-10', '2017-02-12', '15,000 Rs', '02', '200 Rs', '14,800 Rs'),
(2, 'pratikjoil999@gmail.com', 'pratik', 'morning', '2017-02-10', '2017-03-09', '12,000 Rs', '00', '200 Rs', '11,800 RS'),
(3, 'pratikjoil999@gmail.com', 'pratik', 'morning', '2017-02-10', '2017-04-11', '16,000 Rs', '02', '200 Rs', '15,800 Rs'),
(8, 'kamble.swapnil96@gmail.com', 'swapnil', 'morning', '2017-02-21', '2017-02-21', '20,000 Rs', '05', '2,500 Rs', '17,500 Rs');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`user-id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `mpayment`
--
ALTER TABLE `mpayment`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `mrecord`
--
ALTER TABLE `mrecord`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `srecord`
--
ALTER TABLE `srecord`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `staffsalary`
--
ALTER TABLE `staffsalary`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `user-id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `mpayment`
--
ALTER TABLE `mpayment`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `mrecord`
--
ALTER TABLE `mrecord`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `srecord`
--
ALTER TABLE `srecord`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `staffsalary`
--
ALTER TABLE `staffsalary`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
